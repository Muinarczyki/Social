/*
Author: Ivan Odintsov
Twitter: @odintsov_design
*/
var mousewheelevt = (isMobile()) ? "touchmove" : (navigator.userAgent.match(/Firefox/i)) ? "DOMMouseScroll" : "mousewheel";
var STARTY;

function isMobile() {
  return (navigator.userAgent.match(/Android/i) ||
    navigator.userAgent.match(/BlackBerry/i) ||
    navigator.userAgent.match(/iPhone|iPad|iPod/i) ||
    navigator.userAgent.match(/Opera Mini/i) ||
    navigator.userAgent.match(/IEMobile/i));
}

function showOnScrollUp(event) {
  var event = window.event || event;
  var deltaY = -event.detail || event.wheelDelta || event.touches[0].pageY - STARTY;
  var header_h = document.getElementById('header').offsetHeight;
  if (deltaY < 0) {
    header.setAttribute('style', 'transform: translateY( -' + header_h + 'px);');
  } else {
    header.setAttribute('style', '');
  }
}

function touchStart(event) {
  STARTY = event.touches[0].pageY;
}

document.addEventListener('touchstart', touchStart, false)
document.addEventListener(mousewheelevt, showOnScrollUp, false)