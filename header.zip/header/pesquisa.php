<?php
	<!DOCTYPE html>
	<html>
	<head>
		<title>
			pesquisa
		</title>
		<link rel="stylesheet" type="text/css" href="estilos.css">
	</head>
	<body>
		<input type="text" id="pesquisa">
	</body>
	</html>
?php>