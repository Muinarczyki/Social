<!DOCTYPE html>
  <html>
    <head>
      <meta charset="UTF-8">
      <title>Header</title>  
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
      <header id="header" class="header_main">
        <div class="logo">
          <img src="logo.png" id="logotipo">
        </div>
        <span class="nav"></span>
        <?php
          include 'includes/pesquisa/index.php';
        ?>
        <a href="#" id="linkPerfil">
          <div id="perfilRapido" class="hover">
            <img src="avatar.png" id="avatar">
            <h2 id="nomeUsuario">
              Jubileu Fonseca
            </h2>
            <h3 id="level">
              LEVEL 10
            </h3>
            <h4 id="experiencia">
              23%
            </h4>
          </div>
        </a>
      </header>
      <script src="js/index.js"></script> 
    </body>
  </html>