<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Barra de Pesquisa</title>
    <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/style.css"> 
  </head>
  <body>
    <form class="search_bar">
      <input type="text" placeholder="Pesquise no site inteiro!" />
      <button type="submit" value="Pesquisar">Pesquisar</button>
    </form>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src="js/index.js"></script>
  </body>
</html>
