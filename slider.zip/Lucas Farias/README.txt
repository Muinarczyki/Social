A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/pybEzz.

 Was tired of heavy bloated jQuery slider plugins so I made my own. Has controls and finds your slide height/width automatically. Simple & basic, the way momma would have wanted.

Forked from [Mark Peck](http://codepen.io/doodlemarks/)'s Pen [Very Simple Slider](http://codepen.io/doodlemarks/pen/aFcly/).