<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Very Simple Slider</title>
      <link rel="stylesheet" href="css/style.css">

    
    
    
  </head>

  <body>

    <h1>Incredibly Basic Slider</h1>
<div id="slider">
  <a href="#" class="control_next">></a>
  <a href="#" class="control_prev"><</a>
  <ul>
    <li>SLIDE 1</li>
    <li style="background: #aaa;">SLIDE 2</li>
    <li>SLIDE 3</li>
    <li style="background: #aaa;">SLIDE 4</li>
    <li style="background: #b0c4de;">SLIDE 5</li>    
  </ul>  
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
      <script src="js/index.js"></script>

    
    
    
  </body>
</html>
