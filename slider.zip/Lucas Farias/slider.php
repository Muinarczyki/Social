<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
	include('slides.php');
?>
</body>
</html>