A Pen created at CodePen.io. You can find this one at http://codepen.io/jamalAzmy/pen/Jytrv.

 Social Footer with long shadows