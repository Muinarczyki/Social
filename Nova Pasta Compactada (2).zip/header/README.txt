A Pen created at CodePen.io. You can find this one at http://codepen.io/ivanodintsov/pen/ojzJgE.

 When you scroll down header hidden and vice versa